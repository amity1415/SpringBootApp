package com.example.MovieBooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
