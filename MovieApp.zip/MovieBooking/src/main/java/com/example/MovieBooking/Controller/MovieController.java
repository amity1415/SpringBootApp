package com.example.MovieBooking.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.MovieBooking.model.Movie;
import com.example.MovieBooking.model.User;
import com.example.MovieBooking.service.BookingService;
import com.example.MovieBooking.service.MovieService;

@RestController
public class MovieController {

	@Autowired
	MovieService movieService;
    
    @SuppressWarnings("deprecation")
	@PostMapping(value="/movie/save",  consumes={MediaType.APPLICATION_JSON_UTF8_VALUE})
    public Movie saveUser(
    		@RequestBody Movie movie) {
        return movieService.saveMovie(movie);
    }

}
