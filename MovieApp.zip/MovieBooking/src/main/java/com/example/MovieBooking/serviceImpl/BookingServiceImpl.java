package com.example.MovieBooking.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.example.MovieBooking.model.Booking;
import com.example.MovieBooking.repository.BookingRepository;
import com.example.MovieBooking.service.BookingService;

@Service
@Primary
public class BookingServiceImpl implements BookingService {
   
	@Autowired
	BookingRepository bookingRepository;


    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @Override
    public Booking getBookingById(Long booking_id) {
    	
       return bookingRepository.findById(booking_id).get();
    }

    @Override
    public Booking pushBooking(Booking newBooking) {
        return bookingRepository.save(newBooking);
    }

    @Override
    public Booking updateBooking(Booking updatedBooking, Long booking_id) {
    	return bookingRepository.findById(booking_id).map((booking)->{
        	booking.setActive(updatedBooking.isActive());
        	booking.setBooked(updatedBooking.isBooked());
        //	booking.setBookedSeats(updatedBooking.getBookedSeats());
        	booking.setBookingTime(updatedBooking.getBookingTime());
        //	booking.setScreening(updatedBooking.getScreening());
        	booking.setUser(updatedBooking.getUser());
        	
        	return bookingRepository.save(booking);
        	
        	}).orElseGet(()-> {
        		updatedBooking.setId(booking_id);
        		return bookingRepository.save(updatedBooking);
        	});
    }

    @Override
    public void deleteBookingById(Long booking_id) {
    	bookingRepository.deleteById(booking_id);
    }
}
