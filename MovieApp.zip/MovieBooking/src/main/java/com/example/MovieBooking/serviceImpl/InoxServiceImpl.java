package com.example.MovieBooking.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.MovieBooking.model.Inox;
import com.example.MovieBooking.repository.InoxRepository;
import com.example.MovieBooking.service.InoxService;

@Service
public class InoxServiceImpl implements InoxService {

	@Autowired
	InoxRepository inoxRepository;
	
	@Override
	public Inox pushBooking(Inox inoxBooking) {
		Inox inox = inoxRepository.save(inoxBooking);
		return inox;
	}

	@Override
	public List<Inox> getAllInoxBookings() {
		List<Inox> inoxList = inoxRepository.findAll();
		return inoxList;
	}

}
