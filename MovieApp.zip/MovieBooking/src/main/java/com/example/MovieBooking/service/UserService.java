package com.example.MovieBooking.service;

import java.util.List;

import com.example.MovieBooking.model.Booking;
import com.example.MovieBooking.model.User;

public interface UserService {
    List<User> getAllUsers();

    User getUserById(Integer user_id);

    User pushUser(User newUser);

    User updateUser(User updatedUser, Integer user_id);

    void deleteUserById(Integer user_id);

	List<Booking> getBookingByUserId(Integer id);
    
   
}
