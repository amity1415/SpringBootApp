package com.example.MovieBooking.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.MovieBooking.model.Booking;
import com.example.MovieBooking.model.Inox;
import com.example.MovieBooking.service.InoxService;
@RestController
public class InoxController {

	@Autowired
	InoxService inoxService;
	
	 @GetMapping("/inoxbooking")
	    public List<Inox> getAllInoxBookings() {
	        return inoxService.getAllInoxBookings();
	    }
	    
	    @PostMapping(value = "/inoxbookings/add", consumes={"application/json"} )
	    public Inox addInoxBooking(@RequestBody Inox inoxBooking  ) {
	        return inoxService.pushBooking(inoxBooking);
	    }
}
