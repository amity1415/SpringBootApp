package com.example.MovieBooking.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.MovieBooking.model.Booking;

import com.example.MovieBooking.model.Inox;
import com.example.MovieBooking.model.User;
import com.example.MovieBooking.service.UserService;



@RestController
public class UserController {
    private UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/users")
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }
    
  
    
    @GetMapping("/users/{id}")
    public User getUserById(
    		@PathVariable("id") Integer id) {
    
        return userService.getUserById(id);
    }
    
    @SuppressWarnings("deprecation")
	@PostMapping(value="/users/save",  consumes={MediaType.APPLICATION_JSON_UTF8_VALUE})
    public User saveUser(
    		@RequestBody User user) {
        return userService.pushUser(user);
    }
    
    @PutMapping("/users/{id}/update")
    public User updateUser(
    	 @RequestBody User user, @PathVariable("id") Integer id) {
        return userService.updateUser(user, id);
    }
    
    @DeleteMapping("/users/{id}")
    public void updateUser(
    	  @PathVariable("id") Integer id) {
       userService.deleteUserById(id);
    }
    
    @GetMapping( value="/users/{id}/booking")
    public List<Booking> getBookingByUserId( @PathVariable("id") Integer id)
    {
    	return userService.getBookingByUserId(id);
    }
    	
}

