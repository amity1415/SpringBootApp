package com.example.MovieBooking.serviceImpl;


import com.example.MovieBooking.model.Booking;
import com.example.MovieBooking.model.User;
import com.example.MovieBooking.repository.BookingRepository;
import com.example.MovieBooking.repository.UserRepository;
import com.example.MovieBooking.service.UserService;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.List;
 
@Service
@Primary
public class UserServiceImpl implements UserService {
	
	
    private UserRepository userRepository;
    private BookingRepository bookingRepository;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUserById(Integer user_id) {
        return userRepository.findById(user_id).get();
    }

    @Override
    public User pushUser(User newUser) {
        return userRepository.save(newUser);
    }

    @Override
    public User updateUser(User updatedUser, Integer user_id) {
    	return userRepository.findById(user_id).map((user)->{
    	user.setBookings(updatedUser.getBookings());
    	user.setPassword(updatedUser.getPassword());
    	user.setUserName(updatedUser.getUserName());
    	return userRepository.save(user);
    	}).orElseGet(()-> {
    		updatedUser.setId(user_id);
    		return userRepository.save(updatedUser);
    	});
		
    	
       // return user;
        
    }

    @Override
    public void deleteUserById(Integer user_id) {
    	userRepository.deleteById(user_id);;
    }

	@Override
	public List<Booking> getBookingByUserId(Integer id) {
	
		return bookingRepository.getByUserId(Long.parseLong(id.toString()));
		
	}

	
}
