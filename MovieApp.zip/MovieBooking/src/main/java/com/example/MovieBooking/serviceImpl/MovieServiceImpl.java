package com.example.MovieBooking.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.MovieBooking.model.Movie;
import com.example.MovieBooking.repository.MovieRepository;
import com.example.MovieBooking.service.MovieService;

@Service
public class MovieServiceImpl implements MovieService{

	@Autowired
	MovieRepository movieRepo;
	@Override
	public Movie saveMovie(Movie movie) {
		return movieRepo.save(movie);
	
	}

}
