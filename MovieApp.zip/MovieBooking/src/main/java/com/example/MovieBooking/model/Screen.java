package com.example.MovieBooking.model;

import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "screens")
public class Screen {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "screen_id")
	private Long id;
	
	@Column(name = "screen_type")
	private String type;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	   @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(name = "inox_id", nullable = true)
	 
	    private Inox inox;
	   

		 @OneToOne(mappedBy = "screen", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
		    private Movie movie;
}
