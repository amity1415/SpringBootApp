package com.example.MovieBooking.service;

import java.util.List;
import java.util.Set;

import com.example.MovieBooking.model.Booking;
import com.example.MovieBooking.model.Inox;

public interface InoxService {

	
	 Inox pushBooking(Inox inoxBooking);
	 List<Inox> getAllInoxBookings();
}
