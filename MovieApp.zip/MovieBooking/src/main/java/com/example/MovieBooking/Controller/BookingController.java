package com.example.MovieBooking.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.MovieBooking.model.Booking;
import com.example.MovieBooking.service.BookingService;



@RestController
public class BookingController {
    private BookingService bookingService;

    @Autowired
    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @GetMapping("/bookings")
    public List<Booking> getAllBookings() {
        return bookingService.getAllBookings();
    }
    
    @PostMapping(value = "/bookings/add", consumes={"application/json"} )
    public Booking addBooking(@RequestBody Booking booking  ) {
        return bookingService.pushBooking(booking);
    }
}
