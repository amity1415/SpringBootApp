package com.example.MovieBooking.service;

import com.example.MovieBooking.model.Movie;

public interface MovieService {

	public Movie saveMovie(Movie movie);
}
